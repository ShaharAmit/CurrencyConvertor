package com.Shenkar_Java.Final_Project;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
//mange and archive currencies history
public class HistoryManger {
    Currency [] currArr;
    String dateInfo;
    PrintWriter pw;
    public HistoryManger(Currency[] currencies ,String date) throws FileNotFoundException, UnsupportedEncodingException {
        currArr =currencies;
        dateInfo = date;
    }
    //write history to file
    public void ArchivedCurrenciesInfo() throws IOException {
        FileReader file = null;
        String[] lines = new String[currArr.length];
        try {
            file  =  new FileReader("history.txt");


        }catch (FileNotFoundException ex) {
            CurrencyHolder.log.error(ex);
            ex.printStackTrace();
        }

        BufferedReader reader = new BufferedReader(file);
        for(int i = 0; i< currArr.length; i++){
            lines[i] = reader.readLine() + dateInfo +","+ currArr[i].getRate();
        }
        pw = new PrintWriter("history.txt", "UTF-8");
        for(int i = 0; i< currArr.length; i++){
            pw.println(lines[i]+"#");
        }
        pw.close();
    }
    //return an array of currencies  history information
    public CurrencyHistoryObj[] LoadDataHistory() throws IOException {
        CurrencyHistoryObj[] currencyHistoryObj = null;
        String[] lines = null;
        FileReader file = null;
        String[] spiltString;
        String[] spiltString2;

        try {
            file  =  new FileReader("history.txt");
            lines = new String[currArr.length];

        }catch (FileNotFoundException ex) {
            CurrencyHolder.log.error(ex);
            ex.printStackTrace();
        }
        String name;
        List<String> dateArr = new ArrayList<String>();
        List<Double> ratesArr = new ArrayList<Double>();
        currencyHistoryObj = new CurrencyHistoryObj[currArr.length];
        BufferedReader reader = new BufferedReader(file);
        for(int i = 0; i< currArr.length; i++){
            lines[i] = reader.readLine();
            spiltString = lines[i].split(":",-1);
            name = spiltString[0];
            lines[i] = spiltString[1];
            spiltString = lines[i].split("#",-1);

            for(int j =0 ; j<spiltString.length-1;j++){
                spiltString2 = spiltString[j].split(",",-1);
                dateArr.add(spiltString2[0]);
                ratesArr.add(Double.parseDouble(spiltString2[1]));
            }
            currencyHistoryObj[i] = new CurrencyHistoryObj(name,dateArr,ratesArr);
            dateArr.clear();
            ratesArr.clear();
        }

        return  currencyHistoryObj;
    }
    //holds currency history information;
    class CurrencyHistoryObj{
        String name;
        List<String> dates ;
        List <Double> rates;

        public CurrencyHistoryObj(String name, List<String> dateList, List<Double>ratesList) {
            this.name = name;
            this.dates = new ArrayList<String>(dateList);
            this.rates = new ArrayList<Double>(ratesList);
        }
    }
}
