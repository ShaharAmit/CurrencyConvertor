package com.Shenkar_Java.Final_Project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.*;

public class Calculator extends JFrame  {
    //decelerations on calculator variable
    Currency[] currenciesObjList;
    String lastDateUpDate ;
    String [] currNames ;
    Double[] currRates;
    int[] currUnit;
    JComboBox cmbCurrListFrom ;
    JComboBox cmbCurrListTo ;
    JLabel lblFrom = new JLabel();
    JLabel lblTo = new JLabel();
    JLabel lblResult = new JLabel();
    JButton btCalc = new JButton("Convert");
    JTextField txtInput = new JTextField("",20);
    int fIndex = 0, tIndex = 0;

    //constrictor
    public Calculator(Currency[] currencies , String date) {
        currenciesObjList = currencies;
        lastDateUpDate = date;
        currNames = getNames();
        currRates = getCurrRates();
        currUnit = getCurrUnit();
        cmbCurrListFrom = new JComboBox(currNames);
        cmbCurrListTo = new JComboBox(currNames);

        //sating the frame white wallpaper
        setLayout(new BorderLayout());
        setContentPane(new JLabel(new ImageIcon("./img/calcback.png")));
        setLayout(new FlowLayout());
        setResizable(false);
        setLayout(null);
        setSize(700,400);
        setResizable(false);
        setTitle("Converter");

        //sating the frame white components

        cmbCurrListFrom.setSelectedIndex(0);
        cmbCurrListTo.setSelectedIndex(0);

        lblFrom.setText("From: ");
        lblTo.setText("To: ");
        add(txtInput);
        add(lblFrom);
        add(cmbCurrListFrom);
        add(lblTo);
        add(cmbCurrListTo);
        add(btCalc);
        lblResult.setText("");
        add(lblResult);
        txtInput.setBounds(30,10,70,20);
        lblFrom.setBounds(30,35,100,20);
        cmbCurrListFrom.setBounds(70,35,250,30);
        lblTo.setBounds(360,35,100,20);
        cmbCurrListTo.setBounds(390,35,250,30);
        btCalc.setBounds(300,90,100,20);
        lblResult.setBounds(335,130,100,20);

        //components handlers
        HandlerBTCalc  handlerBTCalc = new HandlerBTCalc();
        HandlerCmbFrom  handlerCmbForm = new HandlerCmbFrom();
        HandlerCmbTo  handlerCmbTo = new HandlerCmbTo();


        btCalc.addActionListener(handlerBTCalc);
        cmbCurrListFrom.addActionListener(handlerCmbForm);
        cmbCurrListTo.addActionListener(handlerCmbTo);

    }
    //activate the calculation function
    private class  HandlerBTCalc implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String input  = txtInput.getText();
            Double res = Conversion(currRates[fIndex], currRates[tIndex], currUnit[fIndex], currUnit[tIndex],input);
            DecimalFormat df = new DecimalFormat("#.###");
            String pr = String.valueOf(df.format(res));
            lblResult.setText(pr);
            CurrencyHolder.log.info("user pressing conversion");

        }
    }
    //return the index in the combo box  "from  currency"
    private class  HandlerCmbFrom implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == cmbCurrListFrom){
                JComboBox cb = (JComboBox) e.getSource();
                fIndex = cb.getSelectedIndex();
                CurrencyHolder.log.info("user choose to convert from" + currNames[fIndex]);
            }
        }
    }
    //return the index in the combo box  "to  currency"
    private class  HandlerCmbTo implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == cmbCurrListTo){
                JComboBox cb = (JComboBox) e.getSource();
                tIndex = cb.getSelectedIndex();
                CurrencyHolder.log.info("user choose to convert to" + currNames[tIndex]);


            }
        }
    }


    public String[] getNames(){
        String [] res = new String[currenciesObjList.length];
        for (int i=0 ;i<currenciesObjList.length;i++){
            res[i] = currenciesObjList[i].code +" - " +  currenciesObjList[i].getName() + " (" + currenciesObjList[i].getCountry()+")" ;
        }
        return res;
    }
    public Double[] getCurrRates(){
        Double [] res = new Double[currenciesObjList.length];
        for (int i=0 ;i<currenciesObjList.length;i++){
            res[i] = currenciesObjList[i].getRate();
        }
        return res;
    }
    public int[] getCurrUnit(){
        int [] res = new int[currenciesObjList.length];
        for (int i=0 ;i<currenciesObjList.length;i++){
            res[i] = currenciesObjList[i].getUnit();
        }
        return res;
    }
    //conversion function
    public static Double Conversion(Double fRate, Double tRate, int fUnit, int tUnit, String input){
        Double res = null;
        try {
            int inputNun = Integer.parseInt(input);
            res = (((fRate/fUnit)*inputNun)/tRate)*tUnit;

        }
        catch (NumberFormatException e){
            CurrencyHolder.log.error("input is invalid ");
            res = Double.valueOf(0);
        }
        return res;
    }

}

