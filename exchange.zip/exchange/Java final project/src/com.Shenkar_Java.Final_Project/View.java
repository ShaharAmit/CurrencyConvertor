package com.Shenkar_Java.Final_Project;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

public class View extends JFrame  {
    Currency[] currenciesObjList;
    String  lastDate;
    Table table;
    Calculator calc;
    JLabel lblDateInfo;
    Graph graph;
    public View(Currency[] currencies , String date) throws IOException {
        currenciesObjList = currencies;
        lastDate = date;
        setSize(400,600);
        setTitle("Currencies Rate application");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        lblDateInfo = new JLabel("Update to:" + lastDate);
        lblDateInfo.setBounds(250,400,300,300);
        lblDateInfo.setForeground (Color.white);

        Icon tableIcon = new ImageIcon("./img/table.png");
        JButton btOpenTable = new JButton(tableIcon);
        btOpenTable.setBounds(50,100,300,75);

        Icon calcIcon = new ImageIcon("./img/calculator.png");
        JButton btOpenCalc = new JButton(calcIcon);
        btOpenCalc.setBounds(50,180,300,75);

        Icon graphIcon = new ImageIcon("./img/chart.png");
        JButton btGraph = new JButton(graphIcon);
        btGraph.setBounds(50,260,300,75);

        Icon updateIcon = new ImageIcon("./img/update.png");
        JButton btUpdate = new JButton(updateIcon);
        btUpdate.setBounds(50,340,300,75);





        setLayout(new BorderLayout());
        setContentPane(new JLabel(new ImageIcon("./img/menuBackGround.png")));
        setLayout(new FlowLayout());
        setLayout(null);
        setResizable(false);
        add(btOpenTable);
        add(btOpenCalc);
        add(btGraph);
        add(btUpdate);
        add(lblDateInfo);


        HandlerBtOpenCalc handlerBtOpenCalc = new HandlerBtOpenCalc(currenciesObjList,lastDate);
        btOpenCalc.addActionListener(handlerBtOpenCalc);

        HandlerBtOpenTable handlerBtOpenTable = new HandlerBtOpenTable(currenciesObjList,currenciesObjList.length);
        btOpenTable.addActionListener(handlerBtOpenTable);

        HandlerBtGraph handlerBtGraph = new HandlerBtGraph(currenciesObjList , lastDate);
        btGraph.addActionListener(handlerBtGraph);


        HandlerUpdate handlerUpdate = new HandlerUpdate();
        btUpdate.addActionListener(handlerUpdate);

        setVisible(true);

    }


    private class HandlerBtOpenCalc implements ActionListener {
        Currency[] currencies ;
        String date;
        public HandlerBtOpenCalc(Currency[] currencies, String date) {
            this.currencies = currencies;
            this.date = date;
            calc = new Calculator(currencies,date) ;
        }
        public void actionPerformed(ActionEvent e) {
            if (!(calc.isVisible())){
                calc.setVisible(true);
            }
        }

    }
    private class HandlerBtOpenTable implements ActionListener {
        int length;
        Currency[] currencies ;
        public HandlerBtOpenTable(Currency[] currencies, int length) {
            this.length = length;
            this.currencies = currencies;
            table = new Table(currencies,currencies.length);
        }
        public void actionPerformed(ActionEvent e) {
            if (!(table.isVisible())){
                table.setVisible(true);
            }
        }
    }
    private class HandlerBtGraph implements ActionListener {
        public HandlerBtGraph(Currency[] currencies, String date) throws IOException {
            try {
                graph = new Graph(currencies,date);
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        public void actionPerformed(ActionEvent e) {
            try {
                graph.display();
            } catch (IOException e1) {
                e1.printStackTrace();
            }

        }
    }
    private class HandlerUpdate implements ActionListener {
        public  Logger log = LogManager.getLogger(CurrencyHolder.class.getName());
        public void actionPerformed(ActionEvent e) {
            CurrencyHolder.FetchInfo updateFi = new CurrencyHolder.FetchInfo();
            try {
                currenciesObjList = updateFi.loadData();
                lastDate = updateFi.getLastDate();
                lblDateInfo.setText("Update to:" + lastDate);
                if(table.isVisible()){
                    table.dispose();
                    remove(table);
                }
                if (calc.isVisible()){
                    calc.dispose();
                    remove(calc);
                }
                log.info("Data was updated!");
            } catch (FileNotFoundException e1) {
                e1.printStackTrace();
                log.error("Data file not found!");
            } catch (UnsupportedEncodingException e1) {
                e1.printStackTrace();
                log.error("Can't read data!");
            }
        }
    }

}

