package com.Shenkar_Java.Final_Project;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Table extends JFrame {
    JTable table = new JTable();

    DefaultTableModel model = new DefaultTableModel();

    Object[] columns = {"Name", "Unit", "Code", "Country", "Rate", "Change"};

    final JTextField textName = new JTextField();
    final JTextField textUnit = new JTextField();
    final JTextField textCode = new JTextField();
    final JTextField textCountry = new JTextField();
    final JTextField textRate = new JTextField();
    final JTextField textChange = new JTextField();
    final JTextField searchField = new JTextField();
    final JLabel addHint = new JLabel("write to empty fields and tap the 'add' button to add table rows");
    final JLabel searchHint = new JLabel("write to filter");
    final JButton btnAdd = new JButton("Add");
    private TableRowSorter<TableModel> rowSorter;

    Object[] row = new Object[6];
    String[][] data;

    Table(Currency[] currencies,int size){
        model.setColumnIdentifiers(columns);
        table.setModel(model);

        table.setRowHeight(30);

        addHint.setBounds(130,240,682,25);
        searchHint.setBounds(10,335,300,25);

        textName.setBounds(10, 210, 111, 25);
        textUnit.setBounds(121, 210, 111, 25);
        textCode.setBounds(232, 210, 111, 25);
        textCountry.setBounds(343, 210, 111, 25);
        textRate.setBounds(454, 210, 111, 25);
        textChange.setBounds(565, 210, 111, 25);

        searchField.setBounds(10,365,200,25);

        btnAdd.setBounds(290,270,100,25);

        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(10, 10, 682, 200);

        setLayout(new BorderLayout());
        setContentPane(new JLabel(new ImageIcon("./img/tableImg.png")));
        setLayout(new FlowLayout());
        setResizable(false);
        setLayout(null);
        setSize(700,430);
        setTitle("Table");
        setLocationRelativeTo(null);


        add(pane);
        add(textName);
        add(textChange);
        add(textCode);
        add(textCountry);
        add(textRate);
        add(textUnit);

        add(searchField);
        add(searchHint);

        add(addHint);

        add(btnAdd);

        data = new String[size][6];
        for (int i = 0; i < size; i++) {
            data[i][0] = currencies[i].getName();
            data[i][1] = Double.toString(currencies[i].getUnit());
            data[i][2] = currencies[i].getCode();
            data[i][3] = currencies[i].getCountry();
            data[i][4] = Double.toString(currencies[i].getRate());
            data[i][5] = Double.toString(currencies[i].getChange());
        }

        model = new DefaultTableModel(data,columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;//This causes all cells to be not editable
            }
        };
        table.setModel(model);
        rowSorter = new TableRowSorter<>(table.getModel());
        table.setRowSorter(rowSorter);


        // button add row
        btnAdd.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {

                row[0] = textName.getText();
                row[1] = textUnit.getText();
                row[2] = textCode.getText();
                row[3] = textCountry.getText();
                row[4] = textRate.getText();
                row[5] = textChange.getText();


                // add row to the model
                model.addRow(row);

                textName.setText("");
                textUnit.setText("");
                textCode.setText("");
                textCountry.setText("");
                textRate.setText("");
                textChange.setText("");

                JOptionPane.showMessageDialog(null,"Currency added");
            }
        });

        // get selected row data From table to text fields
        table.addMouseListener(new MouseAdapter(){

            @Override
            public void mouseClicked(MouseEvent e){

                // i = the index of the selected row
                int i = table.getSelectedRow();

                textName.setText(model.getValueAt(i, 0).toString());
                textUnit.setText(model.getValueAt(i, 1).toString());
                textCode.setText(model.getValueAt(i, 2).toString());
                textCountry.setText(model.getValueAt(i, 3).toString());
                textRate.setText(model.getValueAt(i, 4).toString());
                textChange.setText(model.getValueAt(i, 5).toString());
            }
        });


        searchField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                String text = searchField.getText();

                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                String text = searchField.getText();

                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }
        });

    }
}